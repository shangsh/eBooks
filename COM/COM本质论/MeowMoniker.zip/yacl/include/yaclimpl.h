/////////////////////////////////////////////////////////////////////////////
// yaclimpl.h: YACL implementation
/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1997, Tim Ewald, Chris Sells and Don Box.
// All rights reserved.
//
// The following is a prototype of a moniker base class.
// NO WARRANTIES ARE EXTENDED. USE AT YOUR OWN RISK.
//
// To contact the authors with suggestions or comments, use
// tewald@obelisk-llc.com,
// csells@sellsbrothers.com and
// dbox@develop.com.

#include "yacl.cpp"
