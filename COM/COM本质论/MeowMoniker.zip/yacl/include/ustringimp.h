// ustringimp.h

#include "ustring.cpp"